# 2. Control de Acceso (RBAC) Adaptado para Vistas UI

Para permitir que el Frontend muestre u oculte menús y botones según el rol del usuario, las respuestas API incluyen el rol del usuario y verifican permisos a nivel de ruta.

## Definición de Roles

1. **Administrador (`administrador`):**
   - Acceso total a paneles de control administrativo.
   - Aprobación/Rechazo de instituciones registradas.
   - Gestión global de usuarios.

2. **Institución (`institucion`):**
   - Acceso al panel institucional (Dashboard de Becas).
   - Crear, editar, activar/desactivar sus propias convocatorias de becas.

3. **Usuario / Postulante (`usuario`):**
   - Búsqueda y filtrado de becas.
   - Postulación/Guardado de becas favoritas.
   - Uso del Chatbot con IA.

## Verificación de Permisos en PHP (`app/helpers/auth.php`)

```php
function checkRole(array $allowedRoles, string $userRole) {
    if (!in_array($userRole, $allowedRoles)) {
        http_response_code(403);
        echo json_encode([
            "success" => false,
            "error" => "No tienes permisos para realizar esta acción"
        ]);
        exit();
    }
}
```
