# 3. Servicio de Correo Electrónico (`EmailService.php`)

Clase modular lista para ser invocada desde los controladores en eventos clave (registro, recuperación de contraseña, notificación).

```php
<?php
// app/services/EmailService.php

class EmailService {
    private $host;
    private $port;
    private $user;
    private $pass;
    private $fromEmail;
    private $fromName;

    public function __construct() {
        $this->host = $_ENV['SMTP_HOST'] ?? 'smtp.example.com';
        $this->port = $_ENV['SMTP_PORT'] ?? 587;
        $this->user = $_ENV['SMTP_USER'] ?? '';
        $this->pass = $_ENV['SMTP_PASS'] ?? '';
        $this->fromEmail = $_ENV['SMTP_FROM_EMAIL'] ?? 'no-reply@biblioteca.app';
        $this->fromName = $_ENV['SMTP_FROM_NAME'] ?? 'Biblioteca App';
    }

    public function sendPasswordReset($email, $token) {
        $link = "https://tu-frontend-ui.com/reset-password?token=" . urlencode($token);
        $subject = "Restablecimiento de Contraseña - Biblioteca App";
        $body = "
            <h2>Recuperación de Contraseña</h2>
            <p>Has solicitado restablecer tu contraseña. Haz clic en el siguiente enlace para continuar:</p>
            <p><a href='{$link}' style='background:#007bff; color:#fff; padding:10px 15px; text-decoration:none; border-radius:5px;'>Restablecer Contraseña</a></p>
            <p><small>Este enlace expira en 15 minutos.</small></p>
        ";
        return $this->sendMail($email, $subject, $body);
    }

    private function sendMail($to, $subject, $htmlContent) {
        $headers  = "MIME-Version: 1.0" . "
";
        $headers .= "Content-type:text/html;charset=UTF-8" . "
";
        $headers .= "From: {$this->fromName} <{$this->fromEmail}>" . "
";
        
        return mail($to, $subject, $htmlContent, $headers);
    }
}
```
