# 6. Plan de Pruebas Automatizadas (PHPUnit)

Estrategia para probar endpoints RESTful que consumirá la UI.

## Configuración `phpunit.xml`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<phpunit bootstrap="vendor/autoload.php" colors="true">
    <testsuites>
        <testsuite name="Unit Suite">
            <directory>tests/Unit</directory>
        </testsuite>
        <testsuite name="Integration Suite">
            <directory>tests/Integration</directory>
        </testsuite>
    </testsuites>
    <php>
        <env name="DB_NAME" value="biblioteca_test"/>
        <env name="JWT_SECRET" value="test_secret_key"/>
    </php>
</phpunit>
```

## Ejemplo de Test de Integración (`tests/Integration/BecaApiTest.php`)

```php
<?php
use PHPUnit\Framework\TestCase;

class BecaApiTest extends TestCase {
    
    public function testListarBecasRetornaJsonValido() {
        $ch = curl_init("http://localhost:8000/api/becas");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $this->assertEquals(200, $httpCode);
        $data = json_decode($response, true);
        $this->assertTrue($data['success']);
        $this->assertIsArray($data['data']);
    }
}
```
