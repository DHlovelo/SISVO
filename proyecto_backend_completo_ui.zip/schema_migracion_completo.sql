-- SQL Consolidado y Listo para Producción / Entorno UI

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `becas`;
DROP TABLE IF EXISTS `instituciones`;
DROP TABLE IF EXISTS `usuarios`;

SET FOREIGN_KEY_CHECKS = 1;

-- 1. Tabla Usuarios
CREATE TABLE `usuarios` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `rol` ENUM('administrador', 'institucion', 'usuario') DEFAULT 'usuario',
  `creado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Tabla Instituciones
CREATE TABLE `instituciones` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` INT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  `siglas` VARCHAR(50),
  `sitio_web` VARCHAR(255),
  `contacto_email` VARCHAR(150),
  `telefono` VARCHAR(50),
  `direccion` TEXT,
  `creado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Tabla Becas
CREATE TABLE `becas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `institucion_id` INT NOT NULL,
  `titulo` VARCHAR(255) NOT NULL,
  `descripcion` TEXT NOT NULL,
  `requisitos` TEXT,
  `area_estudio` VARCHAR(100),
  `nivel_academico` VARCHAR(50),
  `fecha_limite` DATE,
  `estado` ENUM('activa', 'inactiva', 'finalizada') DEFAULT 'activa',
  `creado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`institucion_id`) REFERENCES `instituciones`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Índices para optimizar búsquedas desde la UI
CREATE INDEX idx_becas_area ON becas(area_estudio);
CREATE INDEX idx_becas_estado ON becas(estado);
