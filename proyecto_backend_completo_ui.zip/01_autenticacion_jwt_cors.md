# 1. Autenticación JWT y Configuración CORS para la UI

Para conectar cualquier interfaz gráfica de usuario (UI), los endpoints de API deben manejar los encabezados CORS correctamente y emitir tokens JWT que el cliente pueda almacenar (por ejemplo, en `localStorage` o Cookies `HttpOnly`).

## Configuración de Encabezados CORS (PHP)
Ubicado al inicio de `public/index.php` o en un middleware global:

```php
<?php
// app/helpers/cors.php
function applyCorsHeaders() {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
    header("Access-Control-Allow-Origin: $origin");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Headers: Authorization, Content-Type, X-Requested-With");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
}
```

## Formato de Respuesta de Autenticación (`POST /api/auth/login`)
```json
{
  "success": true,
  "message": "Inicio de sesión exitoso",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": 1,
      "nombre": "Juan Pérez",
      "email": "juan@ejemplo.com",
      "rol": "usuario"
    }
  }
}
```

## Validaciones en Middleware `auth.php`
- Extrae la cabecera `Authorization: Bearer <token>`.
- Si el token es inválido o ha expirado, responde inmediatamente con código HTTP `401 Unauthorized` y payload JSON normalizado.
