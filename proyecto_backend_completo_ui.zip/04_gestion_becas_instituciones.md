# 4. Controladores API RESTful para la Interfaz UI

Estos controladores entregan la estructura limpia que espera la interfaz frontend para renderizar tablas, tarjetas y formularios.

## `BecaController.php`

```php
<?php
// app/controllers/BecaController.php

class BecaController {
    
    // GET /api/becas (Soporta paginación y búsqueda para filtros UI)
    public function index() {
        $search = $_GET['q'] ?? '';
        $area = $_GET['area'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $becaModel = new Beca();
        $becas = $becaModel->search($search, $area, $limit, $offset);
        $total = $becaModel->countTotal($search, $area);

        http_response_code(200);
        echo json_encode([
            "success" => true,
            "data" => $becas,
            "pagination" => [
                "current_page" => $page,
                "total_pages" => ceil($total / $limit),
                "total_records" => $total
            ]
        ]);
    }

    // POST /api/becas (Exclusivo Institución/Admin)
    public function store($authData) {
        $input = json_decode(file_get_contents("php://input"), true);
        
        // Validación básica
        if (empty($input['titulo']) || empty($input['descripcion'])) {
            http_response_code(400);
            echo json_encode(["success" => false, "error" => "Campos obligatorios incompletos"]);
            return;
        }

        $becaModel = new Beca();
        $newId = $becaModel->create([
            "institucion_id" => $input['institucion_id'],
            "titulo" => $input['titulo'],
            "descripcion" => $input['descripcion'],
            "requisitos" => $input['requisitos'] ?? '',
            "area_estudio" => $input['area_estudio'] ?? '',
            "nivel_academico" => $input['nivel_academico'] ?? '',
            "fecha_limite" => $input['fecha_limite'] ?? null
        ]);

        http_response_code(201);
        echo json_encode([
            "success" => true,
            "message" => "Beca creada exitosamente",
            "data" => ["id" => $newId]
        ]);
    }
}
```
