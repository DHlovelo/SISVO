# 5. Controlador de Chatbot & Conexión con n8n

El frontend interactúa con un widget de chat. El controlador PHP recibe el mensaje, realiza una llamada `curl` segura al webhook de **n8n** y devuelve la respuesta al chat de la UI.

## `ChatbotController.php`

```php
<?php
// app/controllers/ChatbotController.php

class ChatbotController {
    
    // POST /api/chatbot/message
    public function sendMessage() {
        $input = json_decode(file_get_contents("php://input"), true);
        $userMessage = trim($input['message'] ?? '');

        if (empty($userMessage)) {
            http_response_code(400);
            echo json_encode(["success" => false, "error" => "El mensaje no puede estar vacío"]);
            return;
        }

        // Webhook URL del workflow activo en n8n
        $n8nWebhookUrl = $_ENV['N8N_WEBHOOK_URL'] ?? 'https://n8n.tu-instancia.com/webhook/chatbot';

        $payload = json_encode([
            "message" => $userMessage,
            "session_id" => $input['session_id'] ?? 'guest',
            "timestamp" => date('Y-m-d H:i:s')
        ]);

        $ch = curl_init($n8nWebhookUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-Secret-Token: ' . ($_ENV['N8N_SECRET_TOKEN'] ?? 'secret_123')
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200 && $response) {
            $data = json_decode($response, true);
            http_response_code(200);
            echo json_encode([
                "success" => true,
                "reply" => $data['reply'] ?? "Lo siento, no pude procesar la respuesta."
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "error" => "Ocurrió un error al comunicarse con el asistente."
            ]);
        }
    }
}
```
