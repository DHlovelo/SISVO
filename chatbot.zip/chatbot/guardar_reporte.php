<?php
// Permitir peticiones (CORS)
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// 1. Configuración de la Base de Datos (Ajusta estos datos según XAMPP/MySQL)
$host = 'localhost';
$dbname = 'sisvov_db';
$user = 'root';
$password = ''; // Por defecto en XAMPP está vacío

// 2. Leer los datos enviados por el frontend (JS Fetch)
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true);

$tipo = isset($input['tipo']) ? trim($input['tipo']) : '';
$email = isset($input['email']) ? trim($input['email']) : '';
$mensaje = isset($input['mensaje']) ? trim($input['mensaje']) : '';

// Validar que no estén vacíos
if (empty($tipo) || empty($email) || empty($mensaje)) {
    echo json_encode(['status' => 'error', 'message' => 'Todos los campos son obligatorios.']);
    exit;
}

try {
    // 3. Conexión a la Base de Datos con PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 4. Insertar el reporte en la tabla "reportes_mantenimiento"
    $sql = "INSERT INTO reportes_mantenimiento (tipo_reporte, correo_contacto, detalle_mensaje) VALUES (:tipo, :email, :mensaje)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':tipo', $tipo);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':mensaje', $mensaje);
    
    if ($stmt->execute()) {
        
        // 5. Opcional: Enviar notificación por correo (requiere servidor SMTP configurado)
        /*
        $to = "admin@sisvov.edu.bo";
        $subject = "Nuevo Reporte de Mantenimiento - SISVOV: " . $tipo;
        $body = "Se ha recibido un nuevo reporte:\n\n"
              . "Tipo: $tipo\n"
              . "Correo del Usuario: $email\n"
              . "Mensaje: $mensaje\n";
        $headers = "From: noreply@sisvov.com";
        mail($to, $subject, $body, $headers);
        */

        echo json_encode(['status' => 'success', 'message' => 'Reporte guardado correctamente en la base de datos.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se pudo guardar el reporte en la base de datos.']);
    }

} catch (PDOException $e) {
    // Si la base de datos no existe o hay error de conexión, captura el error
    echo json_encode(['status' => 'error', 'message' => 'Error de Base de Datos: ' . $e->getMessage()]);
}
?>
