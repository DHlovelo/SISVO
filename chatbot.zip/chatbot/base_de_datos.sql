-- Ejecuta este script en phpMyAdmin o consola MySQL para crear la tabla de reportes

-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS sisvov_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE sisvov_db;

-- Crear la tabla de reportes de mantenimiento
CREATE TABLE IF NOT EXISTS reportes_mantenimiento (
    id_reporte INT AUTO_INCREMENT PRIMARY KEY,
    tipo_reporte VARCHAR(100) NOT NULL,
    correo_contacto VARCHAR(150) NOT NULL,
    detalle_mensaje TEXT NOT NULL,
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado_revision ENUM('Pendiente', 'En Revisión', 'Resuelto') DEFAULT 'Pendiente'
);

-- (Ejemplo de inserción manual para probar)
-- INSERT INTO reportes_mantenimiento (tipo_reporte, correo_contacto, detalle_mensaje) 
-- VALUES ('Sugerencia', 'estudiante@correo.com', 'Me gustaría que agreguen información de la UMSA.');
