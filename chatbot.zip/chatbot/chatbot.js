const knowledgeBase = [
    {
        keywords: ["hola", "buenas", "saludos", "iniciar", "empezar"],
        response: "¡Hola! Bienvenid@ a SISVOV (Sistema de Orientación Vocacional). Estoy aquí para ayudarte a descubrir tu carrera ideal o resolver tus dudas sobre becas e instituciones."
    },
    {
        keywords: ["carrera", "carreras", "oferta", "estudiar", "opciones", "ingenieria", "medicina"],
        response: "Ofrecemos orientación para áreas como: 1. Ciencias Tecnológicas (Sistemas, Redes), 2. Ciencias de la Salud (Medicina, Odontología), 3. Ciencias Empresariales (Administración, Comercial). ¿Cuál te interesa más?"
    },
    {
        keywords: ["beca", "becas", "descuento", "financiamiento", "costos", "pagos"],
        response: "Existen distintos tipos de becas: Beca Excelencia Académica, Beca Social y Convenios Institucionales. ¿Deseas conocer los requisitos para postular?"
    },
    {
        keywords: ["test", "vocacional", "orientacion", "examen", "evaluacion", "cuestionario"],
        response: "¡Excelente decisión! Podemos iniciar el Test Vocacional interactivo de 4 preguntas para darte un diagnóstico con certificado PDF. Responde: ¿Te gusta crear software, cuidar la salud o liderar empresas?"
    },
    {
        keywords: ["requisito", "requisitos", "inscripcion", "documentos", "matricularse"],
        response: "Los requisitos generales son: Fotocopia de Diploma de Bachiller, Certificado de Nacimiento, Carnet de Identidad y 4 fotos 3x4 fondo azul."
    },
    {
        keywords: ["ubicacion", "donde", "sedes", "direccion", "contacto"],
        response: "Contamos con sedes principales y campus universitarios en La Paz, El Alto, Cochabamba y Santa Cruz."
    }
];

let isTestActive = false;
let testStep = 0;
let userAnswers = [];

document.addEventListener('DOMContentLoaded', () => {
    const chatModal = document.getElementById('chat-modal');
    const toggleBtn = document.getElementById('chat-toggle-btn');
    const closeBtn = document.getElementById('close-chat-btn');
    const clearBtn = document.getElementById('clear-chat-btn');
    const sendBtn = document.getElementById('send-btn');
    const userInput = document.getElementById('user-input');
    const voiceBtn = document.getElementById('voice-btn');
    const maintenanceForm = document.getElementById('maintenance-form');
    toggleBtn.addEventListener('click', () => chatModal.classList.toggle('hidden'));
    closeBtn.addEventListener('click', () => chatModal.classList.add('hidden'));
    
    clearBtn.addEventListener('click', () => {
        document.getElementById('messages-list').innerHTML = '';
        document.getElementById('robot-bubble-text').innerText = "¡Hola! Conversación reiniciada. ¿En qué te puedo asesorar?";
        document.getElementById('user-bubble-text').innerText = "...";
        document.getElementById('user-speech-bubble').classList.add('opacity-0');
    });

    sendBtn.addEventListener('click', processUserInput);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') processUserInput();
    });

    maintenanceForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const tipo = document.getElementById('report-type').value;
        const email = document.getElementById('report-email').value;
        const mensaje = document.getElementById('report-message').value;
        const btnSubmit = document.getElementById('btn-submit-report');
        const spinner = document.getElementById('submit-spinner');
        const alertBox = document.getElementById('form-alert');

        btnSubmit.disabled = true;
        spinner.classList.remove('d-none');
        alertBox.classList.add('d-none');

        fetch('guardar_reporte.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ tipo: tipo, email: email, mensaje: mensaje })
        })
        .then(response => response.json())
        .then(data => {
            btnSubmit.disabled = false;
            spinner.classList.add('d-none');

            if (data.status === 'success') {
                alertBox.className = 'alert alert-success mt-3';
                alertBox.innerHTML = '<i class="bi bi-check-circle-fill"></i> ¡Gracias! Tu reporte ha sido enviado con éxito y guardado en la base de datos.';
                alertBox.classList.remove('d-none');
                maintenanceForm.reset();

                setTimeout(() => {
                    bootstrap.Modal.getInstance(document.getElementById('maintenanceModal')).hide();
                    alertBox.classList.add('d-none');
                }, 3000);
            } else {
                alertBox.className = 'alert alert-danger mt-3';
                alertBox.innerHTML = '<i class="bi bi-exclamation-triangle-fill"></i> Error: ' + data.message;
                alertBox.classList.remove('d-none');
            }
        })
        .catch(error => {
            btnSubmit.disabled = false;
            spinner.classList.add('d-none');
            alertBox.className = 'alert alert-danger mt-3';
            alertBox.innerHTML = '<i class="bi bi-exclamation-triangle-fill"></i> Error de conexión con guardar_reporte.php. Verifica que XAMPP esté corriendo.';
            alertBox.classList.remove('d-none');
            console.error('Error Fetch:', error);
        });
    });
});

function processUserInput() {
    const inputField = document.getElementById('user-input');
    const query = inputField.value.trim();
    if (!query) return;

    document.getElementById('user-bubble-text').innerText = query;
    const userBubble = document.getElementById('user-speech-bubble');
    userBubble.classList.remove('opacity-0');

    appendMessage(query, 'user');
    inputField.value = '';

    showTyping(true);

    setTimeout(() => {
        showTyping(false);
        const botReply = generateResponse(query);

        document.getElementById('robot-bubble-text').innerText = botReply;
        appendMessage(botReply, 'bot');

    }, 700);
}

function sendQuickMessage(text) {
    document.getElementById('user-input').value = text;
    processUserInput();
}

function generateResponse(input) {
    const cleanInput = input.toLowerCase();

    for (let item of knowledgeBase) {
        if (item.keywords.some(kw => cleanInput.includes(kw))) {
            return item.response;
        }
    }

    return "Comprendo tu inquietud. Te aconsejo evaluar tus habilidades en ciencias, tecnología o humanidades. ¿Te gustaría realizar el test vocacional guiado?";
}

function appendMessage(text, sender) {
    const list = document.getElementById('messages-list');
    const msgDiv = document.createElement('div');
    msgDiv.className = `message-bubble ${sender} fade-in`;
    msgDiv.innerText = text;
    list.appendChild(msgDiv);

    const body = document.getElementById('chat-body');
    body.scrollTop = body.scrollHeight;
}

function showTyping(show) {
    const indicator = document.getElementById('typing-indicator');
    if (show) indicator.classList.remove('d-none');
    else indicator.classList.add('d-none');
}
